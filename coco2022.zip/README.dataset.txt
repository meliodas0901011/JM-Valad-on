# object detection > 2022-12-07 5:17pm
https://universe.roboflow.com/design-project-b03wf/object-detection-mwrmw

Provided by a Roboflow user
License: CC BY 4.0

